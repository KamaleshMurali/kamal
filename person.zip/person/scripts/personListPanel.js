var personListPanel = {};
personListPanel.person;
personListPanel.persons = [];

personListPanel.createChildren = function () {
    // no childrens
}

personListPanel.createView = function () {
    var response = resource.doGet('personListPanel.html');
    document.getElementById('personPanel').innerHTML += response;
}

personListPanel.prepopulate = function () {
    var personJson = resource.doGet('assets/personDetails.json');
    person = JSON.parse(personJson)
    personListPanel.onCreate(person);
}

personListPanel.onCreate = function (person) {
    var emptyDiv = resource.doGet('divTable.html');
    document.getElementById('personListPanel').innerHTML += emptyDiv;
    var personList = resource.doGet('personTable.html');
    document.getElementById('table').innerHTML += personList;

    var record = resource.doGet('record.html');

    for (var i = 0; i < person.length; i++) {
        // var row = document.querySelector('td');
        // console.log("hello" + row);
        // row.id = 'record' + i;
        // console.log(row);
        var index = record;
        console.log(index);

        // var tableRow  = document.querySelector('tbody');
        // var childNode = tableRow.firstChild;
        // console.log(childNode);
        // console.log(tableRow);
        var replacedRecord = index.replace('%id%', person[i].id)
                                   .replace('%first name%', person[i].firstname)
                                   .replace('%last name%', person[i].lastname)
                                   .replace('%email%', person[i].email)
                                   .replace('%birth date%', person[i].dob)
                                   .replace('%value%', 'record' + i);

        document.getElementById('personRecord').innerHTML += replacedRecord;
    }

    var addButton = resource.doGet('addButton.html');
    document.getElementById('personListPanel').innerHTML += addButton;
}

personListPanel.listenEvents = function () {
    //onselect event
    // personListPanel.recordValue ;
    var personTable = document.getElementById('personTable');
    // var rows = personTable.rows;
    for (var i = 0; i < personTable.rows.length; i++) {
        personTable.rows[i].addEventListener('click', function () {
            // personListPanel.recordValue[0] = this.cells;
            personListPanel.recordValue = this;
            console.log(personListPanel.recordValue);
            eventManager.broadcast('recordSelected', this.cells);
    });
    }
    
    eventManager.subscribe('updateRecord', personListPanel.updateRecord);

    // for (var i = 0; i < personTable.rows.length; i++) {
      // var buttonId = 'deleteBtn' + i;
      // delete
      var deleteButton = document.getElementsByClassName('deleteBtn');
      for (var index = 0; index < deleteButton.length; index++) {
        deleteButton[index].addEventListener('click', 
        function () {
        var table = document.getElementById('personTable');
        table.deleteRow(this.parentNode.rowIndex)
        }
        // personListPanel.onDelete(this)}
        );
      }
      // deleteButton.addEventListener('click', function () {
      // onDelete(this)});
    // }
    // for (var i = 0; i < personTable.rows.length; i++) {
        // personTable.addEventListener('click', function () {
        // document.getElementsById('deleteBtn1').deleteRow(this);
        // });
    // }
    
    // document.getElement
    // onadd event
    // document.getElementById('addBtn').addEventListener('click', 
        // function () {
            // eventManager.broadcast('insertRecord');
        // })
    
    // eventManager.subscribe('newRecord', onCreateRecord);
}

personListPanel.updateRecord = function (data) {

    console.log(personListPanel.recordValue);
    var child = document.getElementById(personListPanel.recordValue.id).children;
    for (var index = 0; index < child.length-1; index++) {
      child[index].innerHTML = data[index];
 }
}

// personListPanel.onRecordInsert = function (data) {
//     var record  = resource.doGet('record.html');
//     var replacedRecord = record.replace("%id%", values[0]);
// }

// personListPanel.onDelete = function () {

    // console.log(this);
// }
personListPanel.onDelete = function (r) {
  var i = r.parentNode.parentNode.rowIndex;
  // console.log(r.parentNode.parentNode.rowIndex);
  document.getElementById('personTable').deleteRow(i);
}

var onCreateRecord = function (data) {

    var personTable = document.getElementById('personTable');
    
    var rowTemplate = resource.doGet('record.html');
    
    var newRecord = rowTemplate.replace("%id%", data[0])
                               .replace("%first name%". data[1])
                               .replace('%last name%', data[2])
                               .replace('%email%', data[3])
                               .replace('%birth date%', data[4]);

    document.getElementById('personRecord').innerHTML += newRecord;
}