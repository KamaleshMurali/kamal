var personListPanel = {};
personListPanel.person;
personListPanel.persons = [];

personListPanel.createChildren = function () {
    // no childrens
}

personListPanel.createView = function () {
    var response = resource.doGet('personListPanel.html');
    document.getElementById('personPanel').innerHTML += response;
}

personListPanel.prepopulate = function () {
    var personJson = resource.doGet('assets/personDetails.json');
    person = JSON.parse(personJson)
    personListPanel.onCreate(person);
}

personListPanel.onCreate = function (person) {
    var emptyDiv = resource.doGet('divTable.html');
    document.getElementById('personListPanel').innerHTML += emptyDiv;
    var personList = resource.doGet('personTable.html');
    document.getElementById('table').innerHTML += personList;

    var record = resource.doGet('record.html');

    for (var i = 0; i < person.length; i++) {
        var index = record;
        console.log(index);

        var replacedRecord = index.replace('%id%', person[i].id)
                                   .replace('%first name%', person[i].firstname)
                                   .replace('%last name%', person[i].lastname)
                                   .replace('%email%', person[i].email)
                                   .replace('%birth date%', person[i].dob)
                                   .replace('%value%', 'record' + i);

        document.getElementById('personRecord').innerHTML += replacedRecord;
    }

    var addButton = resource.doGet('addButton.html');
    document.getElementById('personListPanel').innerHTML += addButton;
}

personListPanel.listenEvents = function () {
    //onselect event

    var personTable = document.getElementById('personTable');

    var firstRecord = document.getElementById('record0');

    personTable.addEventListener('load', function () {
        personListPanel.recordValue = firstRecord;
        personListPanel.recordValue.className = 'highlightRow';
        eventManager.broadcast('recordSelected', firstRecord.cells)
    });
    for (var i = 0; i < personTable.rows.length; i++) {
        personTable.rows[i].addEventListener('click', function () {

            personListPanel.recordValue = this;
            personListPanel.recordValue.className = 'highlightRow';
            eventManager.broadcast('recordSelected', this.cells);
    });
    }
    
    eventManager.subscribe('updateRecord', personListPanel.updateRecord);

    var deleteButton = document.getElementsByClassName('deleteBtn');
    for (var index = 0; index < deleteButton.length; index++) {
      deleteButton[index].addEventListener('click', 
      function () {
      var table = document.getElementById('personTable');
      table.deleteRow(this.parentNode.rowIndex)
      }
      );
    }

    // onadd event
    document.getElementById('addBtn').addEventListener('click', 
        function () {
            eventManager.broadcast('insertRecord');
        })
    
    eventManager.subscribe('newRecord', personListPanel.onCreateRecord);
    
    for (var i =0; i < person.length; i++) {
      if (personInfoPanel.values[0] === person[i].id){
        flag = 0;
      } else {
        flag = 1;
      }
    }
    
    if (flag === 0) {
      personListPanel.updateRecord(values);
    }
    if (flag === 1) {
      personListPanel.onCreateRecord(values);
    }
    
    document.getElementById('resetBtn').addEventListener('click', function () {
        eventManager.broadcast('resetRecord', personListPanel.recordValue)
    });
}

personListPanel.updateRecord = function (data) {

    console.log(personListPanel.recordValue);
    var child = document.getElementById(personListPanel.recordValue.id).children;
    for (var index = 0; index < child.length-1; index++) {
      child[index].innerHTML = data[index];
 }
}

// personListPanel.onRecordInsert = function (data) {
//     var record  = resource.doGet('record.html');
//     var replacedRecord = record.replace("%id%", values[0]);
// }

var onCreateRecord = function (data) {

    var personTable = document.getElementById('personTable');
    
    var rowTemplate = resource.doGet('record.html');
    
    var newRecord = rowTemplate.replace("%id%", data[0])
                               .replace("%first name%". data[1])
                               .replace('%last name%', data[2])
                               .replace('%email%', data[3])
                               .replace('%birth date%', data[4]);

    document.getElementById('personRecord').innerHTML += newRecord;
}